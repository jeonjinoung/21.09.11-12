function longRunningTask() {
  console.log("작업끝");
}
console.log("시작");
longRunningTask();
console.log("다음작업");
