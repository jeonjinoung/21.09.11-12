const a = 0;
a = 1;

let b = 0;
b = 1;

const c;