if (true) {
  var x = 3;
}
console.log(x); //3

if (true) {
  const y = 3;
}
console.log(y);
